# QA REPORT — Phase 4 Static Audit

## Fixed
1. **Player tag bug** — generated player is now tagged `Player`, enabling mission/save systems that find the player by tag.
2. **Mobile vehicle input gap** — vehicle controller now accepts `MobileInput.Vehicle`.
3. **Mobile interaction gap** — building interaction can be triggered by `MobileInput.Interact`.
4. **Save/load state loss** — cash, wanted level and inventory are restored explicitly.
5. **Inventory duplication on repeated load** — inventory is cleared before loading saved items.
6. **Unsafe save writes** — save failures are caught and logged.
7. **Project layout** — nested Phase 3 assets were merged into the active Unity `Assets` directory.
8. **Android build automation** — release APK/AAB build entry points added.

## Cannot be verified in this environment
- Unity C# compilation against Unity 6 assemblies.
- Unity scene serialization/import.
- Play Mode behavior.
- GPU rendering/shaders.
- Android APK installation.
- Touch behavior on physical devices.
- Memory/CPU/battery performance.
- Android permissions and OS-version behavior.
- Signed AAB upload to Play Console.

## Known product limitations still present
The supplied Phase 3 project is a modular prototype, not a complete commercial-scale open-world game. Several systems are foundations rather than full implementations (for example, traffic is a simple loop, NPC scheduling is waypoint-based, and building/phone/weather systems require scene prefabs/UI/content). Phase 4 packaging can prepare this codebase for Android, but it cannot turn missing game content into a finished open-world game automatically.
