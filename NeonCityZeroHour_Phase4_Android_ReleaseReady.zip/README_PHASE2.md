# NEON CITY: ZERO HOUR — Phase 2

Adds the first gameplay-world layer on top of Phase 1:
- NPC pedestrian wandering AI
- Simple continuous traffic loop AI
- Building interaction hook
- First-delivery mission completion system

This is source-level Unity content. Unity Play Mode and Android AAB/APK compilation require a Unity editor with the Android Build Support module installed.

Next: Phase 3 — police AI, economy/jobs, mission chaining, inventory and wanted-state foundation.
