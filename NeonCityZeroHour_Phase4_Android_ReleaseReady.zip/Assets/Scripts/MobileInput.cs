using UnityEngine;

public static class MobileInput
{
    public static Vector2 Move { get; set; }
    public static Vector2 Vehicle { get; set; }
    public static bool Interact { get; set; }
    public static bool Brake { get; set; }

    public static void ResetTransientButtons()
    {
        Interact = false;
        Brake = false;
    }
}
