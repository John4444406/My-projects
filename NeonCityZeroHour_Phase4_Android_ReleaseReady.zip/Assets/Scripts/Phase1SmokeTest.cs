using UnityEngine;

public class Phase1SmokeTest : MonoBehaviour
{
    private void Start()
    {
        Debug.Assert(GameObject.Find("Player") != null, "Phase 1 test: Player missing.");
        Debug.Assert(Camera.main != null, "Phase 1 test: Main Camera missing.");
        Debug.Assert(GameObject.Find("CityGround") != null, "Phase 1 test: Ground missing.");
        Debug.Log("NEON CITY: ZERO HOUR - Phase 1 smoke test initialized.");
    }
}
