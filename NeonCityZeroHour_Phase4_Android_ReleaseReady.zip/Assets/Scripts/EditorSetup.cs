#if UNITY_EDITOR
using UnityEditor;
using UnityEngine;

public static class EditorSetup
{
    [MenuItem("Neon City/Run Release Preparation")]
    private static void RunReleasePreparation()
    {
        AndroidReleaseBuild.Configure();
        AndroidReleaseBuild.PrepareScene();
    }
}
#endif
