using UnityEngine;
namespace NeonCity.AI {
    public class NpcSchedule : MonoBehaviour {
        [SerializeField] private Transform[] waypoints;
        [SerializeField] private float speed = 1.8f;
        private int index;
        void Update() {
            if (waypoints == null || waypoints.Length == 0) return;
            Transform target = waypoints[index % waypoints.Length];
            if (!target) return;
            Vector3 d = target.position - transform.position;
            d.y = 0f;
            if (d.sqrMagnitude < 0.4f) { index = (index + 1) % waypoints.Length; return; }
            transform.position += d.normalized * Mathf.Max(0f, speed) * Time.deltaTime;
            transform.rotation = Quaternion.LookRotation(d.normalized, Vector3.up);
        }
    }
}