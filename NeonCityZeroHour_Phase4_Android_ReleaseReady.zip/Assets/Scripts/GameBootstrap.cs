using UnityEngine;

public class GameBootstrap : MonoBehaviour
{
    [SerializeField] private int citySize = 5;
    [SerializeField] private float blockSize = 24f;

    private void Start()
    {
        BuildLighting();
        BuildGround();
        BuildCity();
        BuildPlayer();
    }

    private void BuildLighting()
    {
        var sun = new GameObject("Sun").AddComponent<Light>();
        sun.type = LightType.Directional;
        sun.intensity = 1.1f;
        sun.transform.rotation = Quaternion.Euler(45f, -35f, 0f);
    }

    private void BuildGround()
    {
        var ground = GameObject.CreatePrimitive(PrimitiveType.Plane);
        ground.name = "CityGround";
        float size = citySize * blockSize;
        ground.transform.localScale = new Vector3(size / 10f, 1f, size / 10f);
    }

    private void BuildCity()
    {
        for (int x = -citySize / 2; x <= citySize / 2; x++)
        {
            for (int z = -citySize / 2; z <= citySize / 2; z++)
            {
                if (Mathf.Abs(x) == citySize / 2 || Mathf.Abs(z) == citySize / 2)
                    continue;

                var building = GameObject.CreatePrimitive(PrimitiveType.Cube);
                building.name = $"Building_{x}_{z}";
                float height = 5f + ((Mathf.Abs(x * 17 + z * 31) % 7) * 1.8f);
                building.transform.position = new Vector3(x * blockSize, height / 2f, z * blockSize);
                building.transform.localScale = new Vector3(15f, height, 15f);
            }
        }
    }

    private void BuildPlayer()
    {
        var player = GameObject.CreatePrimitive(PrimitiveType.Capsule);
        player.name = "Player";
        player.tag = "Player";
        player.transform.position = new Vector3(0f, 1.2f, -10f);
        player.AddComponent<CharacterController>();
        player.AddComponent<PlayerController>();
        var camera = new GameObject("Main Camera").AddComponent<Camera>();
        camera.tag = "MainCamera";
        camera.transform.position = player.transform.position + new Vector3(0f, 5f, -7f);
        camera.transform.LookAt(player.transform.position + Vector3.up);
        var follow = camera.gameObject.AddComponent<ThirdPersonCamera>();
        follow.target = player.transform;
    }
}
