using System.IO;
using UnityEngine;
using NeonCity.Gameplay;
using NeonCity.Police;

namespace NeonCity.Save
{
    public class SaveSystem : MonoBehaviour
    {
        [SerializeField] private Transform player;
        [SerializeField] private PlayerEconomy economy;
        [SerializeField] private Inventory inventory;
        [SerializeField] private WantedSystem wanted;
        [SerializeField] private string fileName = "neoncity_save.json";
        public string SavePath => Path.Combine(Application.persistentDataPath, fileName);

        public void Save()
        {
            if (!player) return;
            PlayerSaveData data = new PlayerSaveData {
                x = player.position.x, y = player.position.y, z = player.position.z,
                cash = economy ? economy.Cash : 0,
                wanted = wanted ? wanted.WantedLevel : 0,
                inventory = inventory != null
                    ? new System.Collections.Generic.List<string>(inventory.Items).ToArray()
                    : System.Array.Empty<string>()
            };
            try
            {
                File.WriteAllText(SavePath, JsonUtility.ToJson(data));
            }
            catch (System.Exception e)
            {
                Debug.LogWarning("Save write failed: " + e.Message);
            }
        }

        public bool Load()
        {
            if (!player || !File.Exists(SavePath)) return false;
            try
            {
                PlayerSaveData data = JsonUtility.FromJson<PlayerSaveData>(File.ReadAllText(SavePath));
                if (data == null) return false;

                player.position = new Vector3(data.x, data.y, data.z);
                if (economy) economy.SetCash(Mathf.Max(0, data.cash));
                if (wanted) wanted.SetWantedLevel(data.wanted);
                if (inventory)
                {
                    inventory.Clear();
                    if (data.inventory != null)
                        foreach (string item in data.inventory) inventory.TryAdd(item);
                }
                return true;
            }
            catch (System.Exception e)
            {
                Debug.LogWarning("Save load failed: " + e.Message);
                return false;
            }
        }
    }
}
