using System;
namespace NeonCity.Save {
    [Serializable]
    public class PlayerSaveData {
        public float x, y, z;
        public int cash;
        public int wanted;
        public int reputation;
        public string[] inventory = Array.Empty<string>();
    }
}