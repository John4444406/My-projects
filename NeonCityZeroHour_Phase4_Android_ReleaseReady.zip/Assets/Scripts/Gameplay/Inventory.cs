using System.Collections.Generic;
using UnityEngine;
namespace NeonCity.Gameplay {
    public class Inventory : MonoBehaviour {
        [SerializeField] private int maxSlots = 12;
        private readonly List<string> items = new();
        public IReadOnlyList<string> Items => items;
        public bool TryAdd(string item) {
            if (string.IsNullOrWhiteSpace(item) || items.Count >= maxSlots) return false;
            items.Add(item.Trim()); return true;
        }
        public void Clear() => items.Clear();
        public bool TryRemove(string item) {
            if (string.IsNullOrWhiteSpace(item)) return false;
            return items.Remove(item.Trim());
        }
    }
}