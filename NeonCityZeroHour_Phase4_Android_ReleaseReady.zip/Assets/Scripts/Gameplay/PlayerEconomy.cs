using UnityEngine;
namespace NeonCity.Gameplay {
    public class PlayerEconomy : MonoBehaviour {
        [SerializeField] private int startingCash = 500;
        public int Cash { get; private set; }
        void Awake() => Cash = Mathf.Max(0, startingCash);
        public void AddCash(int amount) => Cash = Mathf.Max(0, Cash + amount);
        public void SetCash(int amount) => Cash = Mathf.Max(0, amount);
        public bool TrySpend(int amount) {
            if (amount < 0 || Cash < amount) return false;
            Cash -= amount; return true;
        }
    }
}