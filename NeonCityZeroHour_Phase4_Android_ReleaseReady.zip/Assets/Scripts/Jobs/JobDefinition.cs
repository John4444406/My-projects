using UnityEngine;
using NeonCity.Gameplay;
namespace NeonCity.Jobs {
    public class JobDefinition : MonoBehaviour {
        [SerializeField] private string jobName = "Courier";
        [SerializeField] private int payout = 100;
        [SerializeField] private PlayerEconomy economy;
        public bool CompleteJob() {
            if (economy == null) return false;
            economy.AddCash(Mathf.Max(0, payout));
            return true;
        }
        public string JobName => jobName;
    }
}