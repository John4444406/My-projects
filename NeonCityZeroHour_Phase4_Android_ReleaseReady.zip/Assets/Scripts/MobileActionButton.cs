using UnityEngine;
using UnityEngine.EventSystems;

public class MobileActionButton : MonoBehaviour, IPointerDownHandler, IPointerUpHandler
{
    public enum ActionType { Interact, Brake, VehicleThrottle, VehicleReverse, VehicleLeft, VehicleRight }
    [SerializeField] private ActionType actionType;

    public void OnPointerDown(PointerEventData eventData)
    {
        SetState(true);
    }

    public void OnPointerUp(PointerEventData eventData)
    {
        SetState(false);
    }

    private void SetState(bool pressed)
    {
        switch (actionType)
        {
            case ActionType.Interact:
                MobileInput.Interact = pressed;
                break;
            case ActionType.Brake:
                MobileInput.Brake = pressed;
                break;
            case ActionType.VehicleThrottle:
                SetVehicleAxis(0f, pressed ? 1f : 0f);
                break;
            case ActionType.VehicleReverse:
                SetVehicleAxis(0f, pressed ? -1f : 0f);
                break;
            case ActionType.VehicleLeft:
                SetVehicleAxis(pressed ? -1f : 0f, 0f);
                break;
            case ActionType.VehicleRight:
                SetVehicleAxis(pressed ? 1f : 0f, 0f);
                break;
        }
    }

    private static void SetVehicleAxis(float x, float y)
    {
        Vector2 current = MobileInput.Vehicle;
        MobileInput.Vehicle = new Vector2(x == 0f ? current.x : x, y == 0f ? current.y : y);
    }
}
