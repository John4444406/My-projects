using UnityEngine;
using NeonCity.Gameplay;
namespace NeonCity.Missions {
    public class ChainedMission : MonoBehaviour {
        [SerializeField] private string missionId = "mission_01";
        [SerializeField] private int reward = 250;
        [SerializeField] private PlayerEconomy economy;
        public bool Completed { get; private set; }
        public void Complete() {
            if (Completed) return;
            Completed = true;
            if (economy) economy.AddCash(reward);
        }
        public string MissionId => missionId;
    }
}