using UnityEngine;

public class VehicleController : MonoBehaviour
{
    [SerializeField] private float acceleration = 12f;
    [SerializeField] private float maxSpeed = 18f;
    [SerializeField] private float steering = 65f;
    [SerializeField] private float brakeStrength = 24f;
    private float speed;

    private void Update()
    {
        Vector2 mobile = MobileInput.Vehicle;
        float keyboardThrottle = Input.GetAxis("Vertical");
        float keyboardSteer = Input.GetAxis("Horizontal");
        float throttle = Mathf.Abs(mobile.y) > 0.01f ? mobile.y : keyboardThrottle;
        float steer = Mathf.Abs(mobile.x) > 0.01f ? mobile.x : keyboardSteer;

        if (MobileInput.Brake)
            speed = Mathf.MoveTowards(speed, 0f, brakeStrength * Time.deltaTime);
        else
            speed = Mathf.MoveTowards(speed, throttle * maxSpeed, acceleration * Time.deltaTime);

        transform.Rotate(0f, steer * steering * Time.deltaTime * Mathf.Clamp01(Mathf.Abs(speed) / 4f), 0f);
        transform.position += transform.forward * speed * Time.deltaTime;
    }
}
