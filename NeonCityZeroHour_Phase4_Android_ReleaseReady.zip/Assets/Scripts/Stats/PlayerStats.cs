using UnityEngine;
namespace NeonCity.Stats {
    public class PlayerStats : MonoBehaviour {
        [SerializeField] private int maxHealth = 100;
        public int Health { get; private set; }
        public int MissionsCompleted { get; private set; }
        public int Reputation { get; private set; }
        void Awake() => Health = Mathf.Clamp(maxHealth, 1, 1000);
        public void Damage(int amount) => Health = Mathf.Max(0, Health - Mathf.Max(0, amount));
        public void Heal(int amount) => Health = Mathf.Min(maxHealth, Health + Mathf.Max(0, amount));
        public void CompleteMission(int reputationGain = 1) {
            MissionsCompleted++;
            Reputation = Mathf.Clamp(Reputation + reputationGain, -1000, 1000);
        }
    }
}