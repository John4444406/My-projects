using UnityEngine;
namespace NeonCity.Events {
    public class WorldEventDirector : MonoBehaviour {
        [SerializeField] private WorldEvent[] events;
        [SerializeField] private float minimumDelay = 30f;
        [SerializeField] private float maximumDelay = 90f;
        private float timer;
        private float nextEvent;
        void Awake() => Schedule();
        void Update() {
            if (events == null || events.Length == 0) return;
            timer += Time.deltaTime;
            if (timer < nextEvent) return;
            timer = 0f;
            events[Random.Range(0, events.Length)]?.Activate();
            Schedule();
        }
        void Schedule() => nextEvent = Random.Range(Mathf.Max(5f, minimumDelay), Mathf.Max(minimumDelay, maximumDelay));
    }
}