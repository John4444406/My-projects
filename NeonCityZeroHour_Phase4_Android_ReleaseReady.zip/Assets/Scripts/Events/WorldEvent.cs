using UnityEngine;
namespace NeonCity.Events {
    public class WorldEvent : MonoBehaviour {
        [SerializeField] private string eventId = "street_event";
        [SerializeField] private float duration = 20f;
        public bool Active { get; private set; }
        public string EventId => eventId;
        public void Activate() { Active = true; CancelInvoke(); Invoke(nameof(Deactivate), Mathf.Max(1f, duration)); }
        public void Deactivate() { Active = false; }
    }
}