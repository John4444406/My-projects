using UnityEngine;
using UnityEngine.SceneManagement;

public class ReleaseDiagnostics : MonoBehaviour
{
    [SerializeField] private float minimumTargetFrameRate = 30f;

    private void Start()
    {
        Application.targetFrameRate = 60;
        QualitySettings.vSyncCount = 0;
        Screen.sleepTimeout = SleepTimeout.NeverSleep;

        Debug.Log($"NEON CITY release diagnostics: scene={SceneManager.GetActiveScene().name}, " +
                  $"platform={Application.platform}, resolution={Screen.width}x{Screen.height}");

        if (Camera.main == null)
            Debug.LogError("RELEASE CHECK FAILED: Main Camera missing.");

        GameObject player = GameObject.FindGameObjectWithTag("Player");
        if (player == null)
            Debug.LogError("RELEASE CHECK FAILED: Player tag/object missing.");

        if (SystemInfo.systemMemorySize < 2048)
            Debug.LogWarning("LOW-MEMORY DEVICE: " + SystemInfo.systemMemorySize + " MB");

        if (Application.targetFrameRate < minimumTargetFrameRate)
            Debug.LogWarning("Target frame rate below release threshold.");
    }
}
