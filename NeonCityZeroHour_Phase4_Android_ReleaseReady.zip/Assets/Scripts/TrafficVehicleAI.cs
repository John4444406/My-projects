using UnityEngine;

public class TrafficVehicleAI : MonoBehaviour
{
    public float speed = 5f;
    public float loopSize = 35f;
    float t;
    void Update()
    {
        t += speed * Time.deltaTime / loopSize;
        float a = t * Mathf.PI * 2f;
        transform.position = new Vector3(Mathf.Cos(a) * loopSize, transform.position.y, Mathf.Sin(a) * loopSize);
        transform.forward = new Vector3(-Mathf.Sin(a),0,Mathf.Cos(a));
    }
}
