using UnityEngine;

public class InteractableBuilding : MonoBehaviour
{
    [SerializeField] private string buildingName = "Metro Market";
    [SerializeField] private int reward = 50;
    private bool playerNear;

    private void OnTriggerEnter(Collider other)
    {
        if (other.CompareTag("Player")) playerNear = true;
    }

    private void OnTriggerExit(Collider other)
    {
        if (other.CompareTag("Player")) playerNear = false;
    }

    private void Update()
    {
        if (!playerNear) return;
        if (Input.GetKeyDown(KeyCode.E) || MobileInput.Interact)
        {
            Debug.Log($"Entered {buildingName}; reward {reward}");
            MobileInput.Interact = false;
        }
    }
}
