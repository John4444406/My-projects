using System;
namespace NeonCity.Relationships {
    [Serializable]
    public class RelationshipState {
        public string npcId;
        public int trust;
        public int respect;
        public int hostility;
    }
}