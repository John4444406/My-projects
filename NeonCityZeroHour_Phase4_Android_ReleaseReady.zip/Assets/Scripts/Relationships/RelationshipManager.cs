using System.Collections.Generic;
using UnityEngine;
namespace NeonCity.Relationships {
    public class RelationshipManager : MonoBehaviour {
        private readonly Dictionary<string, RelationshipState> states = new();
        public RelationshipState Get(string npcId) {
            if (string.IsNullOrWhiteSpace(npcId)) return null;
            if (!states.TryGetValue(npcId, out RelationshipState state)) {
                state = new RelationshipState { npcId = npcId };
                states[npcId] = state;
            }
            return state;
        }
        public void ChangeTrust(string npcId, int amount) {
            RelationshipState state = Get(npcId);
            if (state == null) return;
            state.trust = Mathf.Clamp(state.trust + amount, -100, 100);
        }
        public void ChangeRespect(string npcId, int amount) {
            RelationshipState state = Get(npcId);
            if (state == null) return;
            state.respect = Mathf.Clamp(state.respect + amount, -100, 100);
        }
    }
}