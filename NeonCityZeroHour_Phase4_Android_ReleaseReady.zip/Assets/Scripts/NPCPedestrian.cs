using UnityEngine;

public class NPCPedestrian : MonoBehaviour
{
    public float speed = 1.5f;
    public float wanderRadius = 12f;
    Vector3 target;

    void Start() => PickTarget();
    void Update()
    {
        Vector3 flat = target - transform.position; flat.y = 0;
        if (flat.magnitude < 1f) PickTarget();
        else
        {
            transform.position += flat.normalized * speed * Time.deltaTime;
            if (flat.sqrMagnitude > 0.01f) transform.forward = Vector3.Lerp(transform.forward, flat.normalized, 6f * Time.deltaTime);
        }
    }
    void PickTarget() => target = transform.position + new Vector3(Random.Range(-wanderRadius,wanderRadius),0,Random.Range(-wanderRadius,wanderRadius));
}
