using System.Collections.Generic;
using UnityEngine;
namespace NeonCity.Phone {
    public class PhoneSystem : MonoBehaviour {
        [SerializeField] private PhoneContact[] contacts;
        private readonly List<string> notifications = new();
        public IReadOnlyList<string> Notifications => notifications;
        public bool IsOpen { get; private set; }

        public void Toggle() => IsOpen = !IsOpen;
        public void AddNotification(string message) {
            if (string.IsNullOrWhiteSpace(message)) return;
            notifications.Add(message.Trim());
            if (notifications.Count > 30) notifications.RemoveAt(0);
        }
        public PhoneContact FindContact(string name) {
            if (contacts == null) return null;
            foreach (PhoneContact contact in contacts)
                if (contact && string.Equals(contact.ContactName, name, System.StringComparison.OrdinalIgnoreCase))
                    return contact;
            return null;
        }
    }
}