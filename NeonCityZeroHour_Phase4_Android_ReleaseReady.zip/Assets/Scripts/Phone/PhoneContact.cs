using UnityEngine;
namespace NeonCity.Phone {
    public class PhoneContact : MonoBehaviour {
        [SerializeField] private string contactName = "Alex";
        [SerializeField] private string number = "0000";
        public string ContactName => contactName;
        public string Number => number;
    }
}