using UnityEngine;
namespace NeonCity.World {
    public enum WeatherState { Clear, Cloudy, Rain, Storm, Fog }
    public class WeatherSystem : MonoBehaviour {
        [SerializeField] private WeatherState initialWeather = WeatherState.Clear;
        public WeatherState Current { get; private set; }
        public float Intensity { get; private set; }
        void Awake() { SetWeather(initialWeather); }
        public void SetWeather(WeatherState state) {
            Current = state;
            Intensity = state switch {
                WeatherState.Clear => 0f,
                WeatherState.Cloudy => 0.25f,
                WeatherState.Rain => 0.65f,
                WeatherState.Storm => 1f,
                WeatherState.Fog => 0.55f,
                _ => 0f
            };
        }
    }
}