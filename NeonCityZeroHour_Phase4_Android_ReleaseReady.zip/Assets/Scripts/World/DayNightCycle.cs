using UnityEngine;
namespace NeonCity.World {
    public class DayNightCycle : MonoBehaviour {
        [SerializeField] private Light sun;
        [SerializeField] private float minutesPerDay = 10f;
        [SerializeField, Range(0f, 24f)] private float startHour = 8f;
        public float Hour { get; private set; }
        void Awake() => Hour = startHour;
        void Update() {
            float safeMinutes = Mathf.Max(0.1f, minutesPerDay);
            Hour = (Hour + (24f / safeMinutes) * Time.deltaTime / 60f) % 24f;
            if (sun) sun.transform.rotation = Quaternion.Euler((Hour / 24f) * 360f - 90f, 170f, 0f);
        }
        public bool IsNight => Hour < 6f || Hour >= 19f;
    }
}