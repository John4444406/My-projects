using UnityEngine;
namespace NeonCity.World {
    public class WeatherScheduler : MonoBehaviour {
        [SerializeField] private WeatherSystem weather;
        [SerializeField] private float changeEverySeconds = 90f;
        private float timer;
        void Update() {
            if (!weather) return;
            timer += Time.deltaTime;
            if (timer < Mathf.Max(5f, changeEverySeconds)) return;
            timer = 0f;
            weather.SetWeather((WeatherState)Random.Range(0, 5));
        }
    }
}