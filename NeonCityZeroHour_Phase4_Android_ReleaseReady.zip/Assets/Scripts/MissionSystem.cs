using UnityEngine;
using NeonCity.Gameplay;

public class MissionSystem : MonoBehaviour
{
    [SerializeField] private string missionName = "First Delivery";
    [SerializeField] private int reward = 250;
    [SerializeField] private Transform target;
    [SerializeField] private float completionDistance = 3f;
    [SerializeField] private Transform player;
    [SerializeField] private PlayerEconomy economy;
    private bool complete;

    private void Start()
    {
        if (!player)
        {
            GameObject p = GameObject.FindGameObjectWithTag("Player");
            if (p) player = p.transform;
        }
    }

    private void Update()
    {
        if (complete || !target || !player) return;
        if (Vector3.Distance(player.position, target.position) <= completionDistance)
        {
            complete = true;
            if (economy) economy.AddCash(Mathf.Max(0, reward));
            Debug.Log($"MISSION COMPLETE: {missionName} +${reward}");
        }
    }
}
