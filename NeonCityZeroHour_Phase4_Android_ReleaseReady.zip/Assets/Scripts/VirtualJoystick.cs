using UnityEngine;
using UnityEngine.EventSystems;

public class VirtualJoystick : MonoBehaviour, IPointerDownHandler, IDragHandler, IPointerUpHandler
{
    [SerializeField] private RectTransform knob;
    [SerializeField] private float radius = 80f;
    private RectTransform area;

    private void Awake() => area = transform as RectTransform;

    public void OnPointerDown(PointerEventData eventData) => OnDrag(eventData);

    public void OnDrag(PointerEventData eventData)
    {
        if (!RectTransformUtility.ScreenPointToLocalPointInRectangle(area, eventData.position, eventData.pressEventCamera, out var local)) return;
        Vector2 value = Vector2.ClampMagnitude(local / radius, 1f);
        if (knob) knob.anchoredPosition = value * radius;
        MobileInput.Move = value;
    }

    public void OnPointerUp(PointerEventData eventData)
    {
        if (knob) knob.anchoredPosition = Vector2.zero;
        MobileInput.Move = Vector2.zero;
    }
}
