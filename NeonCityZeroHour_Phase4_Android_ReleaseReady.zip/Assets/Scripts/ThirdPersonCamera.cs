using UnityEngine;
using UnityEngine.EventSystems;

public class ThirdPersonCamera : MonoBehaviour
{
    public Transform target;
    [SerializeField] private float distance = 7f;
    [SerializeField] private float height = 4f;
    [SerializeField] private float followSpeed = 10f;
    [SerializeField] private float lookSensitivity = 0.18f;
    [SerializeField] private float minPitch = -20f;
    [SerializeField] private float maxPitch = 55f;

    private float yaw;
    private float pitch = 12f;

    private void Start()
    {
        if (target) yaw = target.eulerAngles.y;
    }

    private void Update()
    {
        HandleLookInput();
    }

    private void LateUpdate()
    {
        if (!target) return;

        Quaternion orbit = Quaternion.Euler(pitch, yaw, 0f);
        Vector3 focus = target.position + Vector3.up * 1.2f;
        Vector3 desired = focus - orbit * Vector3.forward * distance + Vector3.up * (height - 1.2f);
        transform.position = Vector3.Lerp(transform.position, desired, followSpeed * Time.deltaTime);
        transform.LookAt(focus);
    }

    private void HandleLookInput()
    {
        // Desktop fallback: hold right mouse and drag.
        if (Input.GetMouseButton(1))
        {
            Vector2 delta = new Vector2(Input.GetAxis("Mouse X"), Input.GetAxis("Mouse Y"));
            ApplyLook(delta);
        }

        // Mobile: drag anywhere outside UI controls.
        for (int i = 0; i < Input.touchCount; i++)
        {
            Touch touch = Input.GetTouch(i);
            if (EventSystem.current && EventSystem.current.IsPointerOverGameObject(touch.fingerId))
                continue;
            if (touch.phase == TouchPhase.Moved)
                ApplyLook(touch.deltaPosition);
        }
    }

    private void ApplyLook(Vector2 delta)
    {
        yaw += delta.x * lookSensitivity;
        pitch = Mathf.Clamp(pitch - delta.y * lookSensitivity, minPitch, maxPitch);
    }
}
