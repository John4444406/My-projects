using UnityEngine;
namespace NeonCity.Police {
    public class WantedSystem : MonoBehaviour {
        [SerializeField, Range(0,5)] private int wantedLevel;
        public int WantedLevel => wantedLevel;
        public void SetWantedLevel(int level) => wantedLevel = Mathf.Clamp(level, 0, 5);
        public void AddHeat(int amount = 1) => wantedLevel = Mathf.Clamp(wantedLevel + Mathf.Max(0, amount), 0, 5);
        public void ClearHeat() => wantedLevel = 0;
        public void ReduceHeat(int amount = 1) => wantedLevel = Mathf.Clamp(wantedLevel - Mathf.Max(0, amount), 0, 5);
    }
}