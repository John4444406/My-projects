using UnityEngine;
namespace NeonCity.Police {
    public class PoliceUnit : MonoBehaviour {
        [SerializeField] private float chaseSpeed = 8f;
        public Transform Target { get; private set; }
        public void SetTarget(Transform target) => Target = target;
        void Update() {
            if (!Target) return;
            Vector3 delta = Target.position - transform.position;
            delta.y = 0;
            if (delta.sqrMagnitude < 1f) return;
            transform.rotation = Quaternion.LookRotation(delta.normalized, Vector3.up);
            transform.position += transform.forward * chaseSpeed * Time.deltaTime;
        }
    }
}