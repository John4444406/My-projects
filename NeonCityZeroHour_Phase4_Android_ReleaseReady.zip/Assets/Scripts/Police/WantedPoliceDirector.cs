using UnityEngine;
namespace NeonCity.Police {
    public class WantedPoliceDirector : MonoBehaviour {
        [SerializeField] private WantedSystem wanted;
        [SerializeField] private PoliceUnit policePrefab;
        [SerializeField] private Transform player;
        [SerializeField] private Transform[] spawnPoints;
        private int spawnedLevel = 0;
        void Update() {
            if (!wanted || !policePrefab || !player || spawnPoints == null || spawnPoints.Length == 0) return;
            int level = wanted.WantedLevel;
            if (level <= spawnedLevel) return;
            for (int i = spawnedLevel; i < level; i++) {
                Transform p = spawnPoints[i % spawnPoints.Length];
                PoliceUnit unit = Instantiate(policePrefab, p.position, p.rotation);
                unit.SetTarget(player);
            }
            spawnedLevel = level;
        }
    }
}