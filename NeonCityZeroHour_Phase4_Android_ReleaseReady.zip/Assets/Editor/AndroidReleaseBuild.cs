#if UNITY_EDITOR
using System.IO;
using UnityEditor;
using UnityEditor.Build.Reporting;
using UnityEditor.SceneManagement;
using UnityEngine;

public static class AndroidReleaseBuild
{
    private const string ScenePath = "Assets/Scenes/Phase1.unity";
    private const string BundleId = "com.neoncity.zerohour";

    [MenuItem("Neon City/Configure Android Release")]
    public static void Configure()
    {
        PlayerSettings.companyName = "Neon City";
        PlayerSettings.productName = "NEON CITY: ZERO HOUR";
        PlayerSettings.bundleVersion = "1.0.0";
        PlayerSettings.applicationIdentifier = BundleId;
        PlayerSettings.Android.bundleVersionCode = 1;
        PlayerSettings.Android.minSdkVersion = AndroidSdkVersions.AndroidApiLevel26;
        PlayerSettings.Android.targetSdkVersion = AndroidSdkVersions.AndroidApiLevel36;
        PlayerSettings.Android.targetArchitectures = AndroidArchitecture.ARM64;
        PlayerSettings.defaultScreenOrientation = ScreenOrientation.LandscapeLeft;
        PlayerSettings.allowedAutorotateToPortrait = false;
        PlayerSettings.allowedAutorotateToPortraitUpsideDown = false;
        PlayerSettings.allowedAutorotateToLandscapeRight = true;
        PlayerSettings.SetScriptingBackend(NamedBuildTarget.Android, ScriptingImplementation.IL2CPP);
        EditorUserBuildSettings.androidBuildSystem = AndroidBuildSystem.Gradle;
        EditorUserBuildSettings.buildAppBundle = true;
        Debug.Log("Android release settings configured. A signing keystore must be supplied for Play Store publishing.");
    }

    [MenuItem("Neon City/Prepare Release Scene")]
    public static void PrepareScene()
    {
        var scene = EditorSceneManager.OpenScene(ScenePath, OpenSceneMode.Single);
        var root = GameObject.Find("Phase1Bootstrap");
        if (root == null)
        {
            root = new GameObject("Phase1Bootstrap");
        }

        EnsureComponent<GameBootstrap>(root);
        EnsureComponent<Phase1SmokeTest>(root);
        EnsureComponent<ReleaseDiagnostics>(root);

        EditorSceneManager.SaveScene(scene);
        Debug.Log("Release scene prepared: " + ScenePath);
    }

    [MenuItem("Neon City/Build Android AAB")]
    public static void BuildAab()
    {
        Configure();
        PrepareScene();
        string outputDir = "Builds/Android";
        Directory.CreateDirectory(outputDir);

        BuildPlayerOptions options = new BuildPlayerOptions {
            scenes = new[] { ScenePath },
            locationPathName = Path.Combine(outputDir, "NeonCityZeroHour.aab"),
            target = BuildTarget.Android,
            options = BuildOptions.None
        };

        BuildReport report = BuildPipeline.BuildPlayer(options);
        if (report.summary.result != BuildResult.Succeeded)
            throw new BuildFailedException("Android AAB build failed: " + report.summary.result);
        Debug.Log("AAB built: " + options.locationPathName);
    }

    [MenuItem("Neon City/Build Android APK (Testing)")]
    public static void BuildApk()
    {
        Configure();
        PrepareScene();
        EditorUserBuildSettings.buildAppBundle = false;
        string outputDir = "Builds/Android";
        Directory.CreateDirectory(outputDir);

        BuildPlayerOptions options = new BuildPlayerOptions {
            scenes = new[] { ScenePath },
            locationPathName = Path.Combine(outputDir, "NeonCityZeroHour.apk"),
            target = BuildTarget.Android,
            options = BuildOptions.Development
        };

        BuildReport report = BuildPipeline.BuildPlayer(options);
        if (report.summary.result != BuildResult.Succeeded)
            throw new BuildFailedException("Android APK build failed: " + report.summary.result);
        Debug.Log("Testing APK built: " + options.locationPathName);
    }

    private static void EnsureComponent<T>(GameObject go) where T : Component
    {
        if (!go.GetComponent<T>()) go.AddComponent<T>();
    }
}
#endif
