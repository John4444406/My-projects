# NEON CITY: ZERO HOUR — Phase 1

Mobile-first Unity prototype foundation.

## Included
- Runtime city-block generation
- Third-person player controller
- Third-person camera
- Keyboard fallback controls for desktop testing
- Mobile virtual joystick input bridge
- Basic vehicle controller foundation
- Phase 1 smoke-test assertions

## Intended next phases
1. NPC pedestrian system and traffic
2. Buildings/interiors and shops
3. Police, missions and economy
4. Weather, day/night and dynamic events
5. Phone, inventory, relationships and save system
6. Android optimization and release build configuration

## Testing note
This environment does not contain the Unity Editor/build toolchain, so an Android APK cannot be compiled here. The scripts are structured for Unity and include a runtime smoke-test component. Compile and Play Mode testing should be run in a Unity installation before release.
