# NEON CITY: ZERO HOUR — Phase 4 Release Preparation

## Completed in this package
- Normalized the Unity project layout so all gameplay scripts are under the active `Assets/` tree.
- Added `Packages/manifest.json` for Unity 6.
- Added Android release configuration targeting IL2CPP, Android API 26 minimum, API 35 target.
- Added Play Store bundle ID: `com.neoncity.zerohour`.
- Added automated scene preparation and Android APK/AAB build menu commands.
- Added runtime release diagnostics.
- Added mobile vehicle control bridge and mobile interaction button support.
- Fixed player tagging used by missions and save/load.
- Fixed save/load cash, wanted level, and inventory restoration.
- Added a test APK build path (Development APK) and release AAB build path.

## Commands in Unity
1. `Neon City > Configure Android Release`
2. `Neon City > Prepare Release Scene`
3. `Neon City > Build Android APK (Testing)`
4. `Neon City > Build Android AAB`

## Remaining release requirements
This environment does not contain Unity 6 or the Android Build Support/SDK toolchain, so an actual APK/AAB cannot be compiled or device-tested here.

Before Play Store submission:
- Install Unity 6000.0.0f1 with Android Build Support, SDK/NDK and OpenJDK.
- Configure a private release keystore; never commit it to the project.
- Set the final legal publisher/company details.
- Replace the placeholder application icon and create real gameplay screenshots from the built game.
- Test on representative low/mid/high Android phones.
- Complete Play Console Data Safety, privacy policy, content rating, target audience, app access and store listing declarations.
- Build a signed AAB for Play Store upload.

## Current Android settings
- Minimum Android API: 26.
- Target Android API: 36 (required for new Google Play submissions from 2026-08-31).
- Scripting backend: IL2CPP.
- Architecture: ARM64.
- Build format for Play Store: AAB.
- Development install testing: APK.
